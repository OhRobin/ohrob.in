# CopyPasta Landing Page

Marketing page for CopyPasta – a tray app that automatically copies your 2FA codes from Gmail to clipboard.

## Features

- Simple HTML/CSS site
- Loom video or GIF demo
- Email collection with Formspree
- Ready for GitHub Pages or custom domain

## Setup

Replace `demo.mp4` and `logo.png` in the `assets/` folder with your own.
Update the form action URL and download link in `index.html`.

## License

MIT
